﻿namespace Interfaces
{ 
    public interface IAlive
    {
        int Food { get; }
    }
}