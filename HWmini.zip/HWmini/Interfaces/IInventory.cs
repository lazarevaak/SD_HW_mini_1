﻿namespace Interfaces
{
	public interface IInventory
	{
		int Number { get; }
	}
}

