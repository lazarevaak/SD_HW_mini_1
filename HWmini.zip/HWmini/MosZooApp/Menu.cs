﻿using MosZooLib;

namespace MosZooApp
{
	public class Menu
	{
        private readonly Zoo _zoo;

        public Menu(Zoo zoo)
        {
            _zoo = zoo;
        }

        private void ShowMenu()
        {
            Console.Clear();
            
            Console.WriteLine("1. Вывести животных и вещи;");
            Console.WriteLine("2. Вывести всех животных;");
            Console.WriteLine("3. Вывести контактных животных;");
            Console.WriteLine("4. Вывести все вещи;");
            Console.WriteLine("5. Вывести нормы корма;");
            Console.WriteLine("6. Вывести отчет по кормам;");

            Console.WriteLine("7. Добавить вещь;");
            Console.WriteLine("8. Добавить животное;");
        
            Console.WriteLine("9. Выход!");
        }

        public void Run()
        {
            while (true)
            {
                Console.Clear();

                ShowMenu();

                var choice = Input.GetIntInput("> Выберите действие: ", 1, 9);

                switch (choice)
                {
                    case 1:
                        Interface.ShowInventory(_zoo);
                        break;
                    case 2:
                        Interface.ShowAllAnimals(_zoo);
                        break;
                    case 3:
                        Interface.ShowContactZoo(_zoo);
                        
                        break;
                    case 4:
                        Interface.ShowAllThings(_zoo);
                        break;
                    case 5:
                        Interface.ShowNorms(_zoo);
                        break;
                    case 6:
                        Interface.ShowFoodReport(_zoo);
                        break;
                    case 7:
                        Interface.AddThing(_zoo);
                        break;
                    case 8:
                        Interface.AddAnimal(_zoo);
                        break;
                    case 9:
                        break;
                }
            }
        }
    }
}

