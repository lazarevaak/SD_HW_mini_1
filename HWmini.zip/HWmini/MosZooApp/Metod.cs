﻿namespace MosZooApp
{
	public class Metod
	{
        public enum AnimalType
        {
            Monkey,
            Rabbit,
            Tiger,
            Wolf
        }

        public enum ThingType
        {
            Computer,
            Table
        }

        public static AnimalType GetAnimalType()
        {
            Console.Clear();
            Console.WriteLine("Тип животного:");

            Console.WriteLine("1. Обезьяна");
            Console.WriteLine("2. Кролик");
            Console.WriteLine("3. Тигр");
            Console.WriteLine("4. Волк");

            return Input.GetIntInput("Выберите тип: ", 1, 4) switch
            {
                1 => AnimalType.Monkey,
                2 => AnimalType.Rabbit,
                3 => AnimalType.Tiger,
                4 => AnimalType.Wolf,
                _ => throw new InvalidOperationException("Животного под таким номером нет в списке, выберите другого.")
            };
        }

        public static ThingType GetThingType()
        {
            Console.Clear();
            Console.WriteLine("Тип вещи:");

            Console.WriteLine("1. Компьютер");
            Console.WriteLine("2. Стол");

            return Input.GetIntInput("Выберите тип: ", 1, 2) switch
            {
                1 => ThingType.Computer,
                2 => ThingType.Table,
                _ => throw new InvalidOperationException("Вещи под таким номером нет в списке, выберите другую.")
            };
        }
    }
}


