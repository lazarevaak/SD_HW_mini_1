﻿using MosZooLib;
using static MosZooApp.Metod;

namespace MosZooApp
{
    public class Interface
    {
        public static void AddAnimal(Zoo zoo)
        {
            try
            {
                Console.Clear();
                var type = Metod.GetAnimalType();
                var food = Input.GetIntInput("Количество еды (кг/день): ", 0, 100);
                var healthy = Input.GetYesNo("Животное здорово? (y/n): ");

                Animal animal = type switch
                {
                    AnimalType.Monkey => new Monkey(food, healthy,
                        Input.GetIntInput("Уровень доброты (0-10): ", 0, 10)),
                    AnimalType.Rabbit => new Rabbit(food, healthy,
                        Input.GetIntInput("Уровень доброты (0-10): ", 0, 10)),
                    AnimalType.Tiger => new Tiger(food,healthy),
                    AnimalType.Wolf => new Wolf(food, healthy),
                    _ => throw new InvalidOperationException("Ошибка получения животного.")
                };

                var result = zoo.AddAnimal(animal);

                if (result)
                {
                    Console.WriteLine("Животное добавлено!");

                }
                else
                {
                    Console.WriteLine("Отказ: животное нездорово");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        public static void AddThing(Zoo _zoo)
        {
            try
            {
                Console.Clear();
               
                Console.WriteLine("\nДобавление вещи:");

                var type = GetThingType();
                var number = Input.GetUniqueNumber("Инвентарный номер: ", _zoo, 1, 9999);

                Thing thing = type switch
                {
                    ThingType.Computer => new Computer(number),
                    ThingType.Table => new Table(number),
                    _ => throw new InvalidOperationException()
                };

                _zoo.AddThing(thing);

                Console.WriteLine("Вещь успешно добавлена!");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        public static void ShowAllAnimals(Zoo _zoo)
        {
            Console.Clear();
            
            Console.WriteLine("\nСписок всех животных:");
            
            foreach (var animal in _zoo.GetAllAnimals())
            {
                Console.WriteLine(animal.ToString());
            }

            Console.ReadKey();
        }

        public static void ShowAllThings(Zoo _zoo)
        {
            Console.Clear();

            Console.WriteLine("\nСписок всех вещей:");

            foreach (var thing in _zoo.GetAllThings())
            {
                Console.WriteLine(thing.ToString());
            }

            Console.ReadKey();
        }

        public static void ShowNorms(Zoo _zoo)
        {
            Console.Clear();
            Console.WriteLine("Кролик - 1 кг");
            Console.WriteLine("Обезьяна - 2 кг");
            Console.WriteLine("Волк - 3 кг");
            Console.WriteLine("Тигр - 4 кг");
            Console.WriteLine("Обезьяна - 5 кг");

            Console.ReadKey();
        }

        public static void ShowFoodReport(Zoo _zoo)
        {
            Console.Clear();
            int totalFood = _zoo.CalculateAllFood();
            
            Console.WriteLine($"\nОбщий расход кормов: {totalFood} кг/день");

            Console.ReadKey();
        }

        public static void ShowContactZoo(Zoo _zoo)
        {
            Console.Clear();
            var contactAnimals = _zoo.GetContactAnimals();


            Console.WriteLine("\nЖивотные для контактного зоопарка:");

            foreach (var animal in contactAnimals)
            {
                Console.WriteLine($"{animal.GetType().Name}");
            }

            Console.ReadKey();
        }

        public static void ShowInventory(Zoo _zoo)
        {
            Console.Clear();
            var inventory = _zoo.GetAllInventory();

            Console.WriteLine("\nИнвентаризация:");

            foreach (var item in inventory)
            {
                Console.WriteLine($"{item.GetType().Name} #{item.Number}");
            }

            Console.ReadKey();
        }
    }
}