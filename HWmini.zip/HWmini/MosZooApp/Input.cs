﻿using MosZooLib;
using System.Drawing;

namespace MosZooApp
{
	public class Input
	{
        public static int GetIntInput(string str, int min, int max)
        {
            while (true)
            {
                Console.WriteLine(str);
                if (int.TryParse(Console.ReadLine(), out int result) && result >= min && result <= max)
                {
                    return result;
                }
                Console.WriteLine($"Ошибка: введите число от {min} до {max}");
            }
        }

        public static bool GetYesNo(string str)
        {
            while (true)
            {
                Console.WriteLine(str);

                string input = Console.ReadLine()?.Trim().ToLower();

                if (input == "да" || input == "нет")
                {
                    return input == "y";
                }

                Console.WriteLine("Введите только 'да' или 'нет'!");
            }
        }

        public static int GetUniqueNumber(string prompt, Zoo zoo, int min, int max)
        {
            while (true)
            {
                // Запрашиваем число у пользователя
                int number = GetIntInput(prompt, min, max);

                // Проверяем, используется ли номер вещью
                bool isUsed = zoo.IsThingNumberUsed(number);

                // Если номер не используется, возвращаем его
                if (!isUsed) return number;

                // Если номер занят, выводим сообщение об ошибке
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Номер {number} уже занят вещью!");
                Console.ResetColor();
            }
        }
    }
}

