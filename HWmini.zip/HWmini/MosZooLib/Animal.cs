﻿namespace MosZooLib;
using Interfaces;

public abstract class Animal : IAlive
{
    public int Food { get; }
    public bool IsHealthy { get; }

    protected Animal(int food, bool ishealthy)
    {

        if (food < 0)
        {
            throw new ArgumentException("Количество еды не может быть отрицательным.");
        }

        Food = food;
        IsHealthy = ishealthy;
    }

    public override string ToString()
    {
        return $"{GetType().Name} | Еда: {Food} кг/день | Здоров: {(IsHealthy ? "Да" : "Нет")}";
    }
}


