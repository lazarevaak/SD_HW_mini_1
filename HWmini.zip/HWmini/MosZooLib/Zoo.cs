﻿using Interfaces;

namespace MosZooLib
{
    public class Zoo
    {
        private readonly List<Animal> _animals = new();
        private readonly List<Thing> _things = new();

        private readonly HashSet<int> _thingNumbers = new();

        private readonly IHealthChecker _healthChecker;

        public Zoo(IHealthChecker healthChecker)
        {
            _healthChecker = healthChecker;
        }

        public bool AddAnimal(Animal animal)
        {
            if (_healthChecker.IsHealthy(animal))
            {
                _animals.Add(animal);

                return true;
            }
            return false;
        }

        public void AddThing(Thing thing)
        {
            if (_thingNumbers.Contains(thing.Number))
            {
                throw new ArgumentException($"Номер {thing.Number} уже используется вещью!");
            }

            _things.Add(thing);
            _thingNumbers.Add(thing.Number);
        }

        public int CalculateAllFood() => _animals.Sum(a => a.Food);

        public IEnumerable<Animal> GetAllAnimals() => _animals;

        public IEnumerable<Thing> GetAllThings() => _things;

        public IEnumerable<Animal> GetContactAnimals() => _animals.OfType<Herbo>().Where(h => h.CanBeInContactZoo);

        public IEnumerable<IInventory> GetAllInventory()
        {
            var result = new List<IInventory>();

            result.AddRange(_things);

            return result;
        }

        public bool IsThingNumberUsed(int number) => _thingNumbers.Contains(number);
    }
}