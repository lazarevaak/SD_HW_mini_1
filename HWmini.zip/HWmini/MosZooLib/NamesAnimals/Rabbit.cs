﻿namespace MosZooLib
{
	public class Rabbit : Herbo
	{
		public Rabbit(int food, bool ishealthy, int kindness)
            : base(food, ishealthy, kindness)
        {

        }
    }
}

