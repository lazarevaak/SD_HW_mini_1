﻿namespace MosZooLib
{
    public class Wolf : Predator
    {
        public Wolf(int food, bool ishealthy)
            : base(food, ishealthy)
        {

        }
    }
}
    

