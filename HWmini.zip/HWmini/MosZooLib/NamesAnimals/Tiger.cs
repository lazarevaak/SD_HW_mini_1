﻿namespace MosZooLib
{
    public class Tiger : Predator
    {
        public Tiger(int food, bool ishealthy)
            : base(food, ishealthy)
        {

        }

        public override string ToString()
        {
            return "Pppppppp";
        }
    }
}

