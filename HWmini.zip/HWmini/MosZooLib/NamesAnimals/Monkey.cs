﻿namespace MosZooLib
{
	public class Monkey : Herbo
	{
		public Monkey(int food, bool ishealthy, int kindness)
            : base(food, ishealthy, kindness)
        {

        }
    }
}

