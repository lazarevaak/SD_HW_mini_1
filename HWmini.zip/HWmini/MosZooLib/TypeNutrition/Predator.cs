﻿namespace MosZooLib
{
    public abstract class Predator : Animal
    {
        protected Predator(int food, bool ishealthy)
            : base(food, ishealthy)
        {

        }
    }
}

