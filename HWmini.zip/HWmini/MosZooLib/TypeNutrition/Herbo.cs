﻿namespace MosZooLib
{
	public abstract class Herbo : Animal
	{
        public int Kindness { get; }

        public bool CanBeInContactZoo => Kindness > 5;

        protected Herbo(int food, bool ishealthy, int kindness)
            : base(food, ishealthy)
        {
            if (kindness < 0 || kindness > 10)
            {
                throw new ArgumentException("Уровень доброты должен быть в диапазоне от 0 до 10.");
            }

            Kindness = kindness;
        }

  
        public override string ToString()
        {
            return base.ToString() + $" | Доброта: {Kindness}/10";
        }
    }
}

