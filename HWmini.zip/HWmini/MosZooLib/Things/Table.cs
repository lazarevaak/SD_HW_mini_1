﻿namespace MosZooLib
{
	public class Table : Thing
	{
		public Table(int number)
			: base(number)
		{

		}
	}
}

