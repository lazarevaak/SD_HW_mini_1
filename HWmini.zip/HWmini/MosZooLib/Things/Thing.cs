﻿using Interfaces;

namespace MosZooLib
{
    public class Thing : IInventory
    {
        public int Number { get; }

        protected Thing(int number)
        {
            if (number < 0)
            {
                throw new ArgumentException("Колличество вещей не может быть меньше 0.");
            }

            Number = number;
        }
    }
}
