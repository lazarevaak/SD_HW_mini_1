﻿namespace MosZooLib
{
    public class Computer : Thing
    {
        public Computer(int number)
            : base(number)
        {

        }
    }
}

