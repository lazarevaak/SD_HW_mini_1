﻿namespace MosZooLib
{
    public interface IHealthChecker
    {
        bool IsHealthy(Animal animal);
    }
}

