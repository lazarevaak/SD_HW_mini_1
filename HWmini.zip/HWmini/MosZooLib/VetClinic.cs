﻿namespace MosZooLib
{
    public class VetClinic : IHealthChecker
    {
        public bool IsHealthy(Animal animal) => animal.IsHealthy;
    }
}